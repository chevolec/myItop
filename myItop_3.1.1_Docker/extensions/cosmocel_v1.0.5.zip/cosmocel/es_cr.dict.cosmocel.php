<?php
/**
 * Localized data
 *
 * @copyright   Copyright (C) 2013 XXXXX
 * @license     http://opensource.org/licenses/AGPL-3.0
 */

Dict::Add('ES CR', 'Spanish', 'Español, Castellano', array(
	// Dictionary entries go here
	'Class:UserRequest/Attribute:needbydate' => 'Fecha Compromiso',
	'Class:UserRequest/Attribute:effort' => 'Esfuerzo (hrs)',
	'Class:UserRequest/Attribute:servicefamily_id' => 'Area',
));
?>
