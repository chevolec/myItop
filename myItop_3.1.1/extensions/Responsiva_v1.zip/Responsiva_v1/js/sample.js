// Sample JS function to be called from a custom menu item
function MyCustomJSFunction(sName)
{
	// nothing fancy here, just popup an alert
	alert(sName);
}

// Sample JS function to be called from a custom menu item
// on a list of objects
function MyCustomJSListFunction(iCount)
{
	alert('There are '+iCount+' element(s) in this list.');
}